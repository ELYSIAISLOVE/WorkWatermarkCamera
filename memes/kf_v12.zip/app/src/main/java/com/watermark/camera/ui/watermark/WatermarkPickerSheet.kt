package com.watermark.camera.ui.watermark

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.watermark.camera.R
import com.watermark.camera.data.model.TimeStyle
import com.watermark.camera.data.model.WatermarkConfig
import com.watermark.camera.data.model.WatermarkTemplate
import com.watermark.camera.data.watermark.TemplateFormCatalog

/**
 * Bottom sheet: left templates, right time styles, independent scroll.
 */
class WatermarkPickerSheet : BottomSheetDialogFragment() {

    var initialConfig: WatermarkConfig = WatermarkConfig()
    var onSelectionChanged: ((WatermarkConfig) -> Unit)? = null

    private lateinit var previewTitle: TextView
    private lateinit var previewBody: TextView
    private lateinit var previewCard: View
    private var config: WatermarkConfig = WatermarkConfig()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.sheet_watermark_picker, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        config = initialConfig.copy(showLocation = true)

        previewTitle = view.findViewById(R.id.pickerPreviewTitle)
        previewBody = view.findViewById(R.id.pickerPreviewBody)
        previewCard = view.findViewById(R.id.pickerPreviewCard)
        view.findViewById<View>(R.id.pickerClose).setOnClickListener { dismiss() }

        val customRow = view.findViewById<View>(R.id.pickerCustomTitleRow)
        val customEt = view.findViewById<EditText>(R.id.pickerCustomTitle)
        customEt?.setText(config.customTitle)
        customEt?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                config = config.copy(customTitle = s?.toString()?.trim().orEmpty())
                refreshPreview()
                onSelectionChanged?.invoke(config)
            }
        })

        val seek = view.findViewById<SeekBar>(R.id.pickerTransparency)
        val seekVal = view.findViewById<TextView>(R.id.pickerTransparencyValue)
        val initialT = (config.transparency.coerceIn(0.3f, 1f) * 100).toInt()
        seek?.progress = initialT
        seekVal?.text = "${initialT}%"
        seek?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val p = progress.coerceIn(30, 100) // min 30%
                if (progress < 30) seek?.progress = 30
                val tVal = p / 100f
                config = config.copy(transparency = tVal)
                seekVal?.text = "${p}%"
                refreshPreview()
                onSelectionChanged?.invoke(config)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })


        val templates = WatermarkTemplate.menuEntries()

        val leftRv = view.findViewById<RecyclerView>(R.id.pickerTemplateGrid)
        leftRv.layoutManager = GridLayoutManager(requireContext(), 2)
        val templateAdapter = TemplateGridAdapter(templates, config.template) { chosen ->
            config = config.copy(template = chosen)
            customRow?.visibility = View.GONE
            refreshPreview()
            onSelectionChanged?.invoke(config)
            showTemplateFieldsDialog(chosen)
        }
        customRow?.visibility = View.GONE
        leftRv.adapter = templateAdapter

        val styles = listOf(
            TimeStyle.DEFAULT,
            TimeStyle.DIGITAL_TUBE,
            TimeStyle.FLIP_CALENDAR,
            TimeStyle.RETRO_SLASH
        )
        val rightRv = view.findViewById<RecyclerView>(R.id.pickerStyleList)
        rightRv.layoutManager = LinearLayoutManager(requireContext())
        val styleAdapter = StyleListAdapter(styles, config.timeStyle) { chosen ->
            config = config.copy(timeStyle = chosen)
            refreshPreview()
            onSelectionChanged?.invoke(config)
        }
        rightRv.adapter = styleAdapter

        refreshPreview()
    }

    private fun refreshPreview() {
        val tmpl: WatermarkTemplate = config.template
        previewTitle.text = tmpl.cardTitle(config.customTitle)
        val timeSample = when (config.timeStyle) {
            TimeStyle.DIGITAL_TUBE -> "12:34:56"
            TimeStyle.FLIP_CALENDAR -> "12:34"
            TimeStyle.RETRO_SLASH -> "12/34/56"
            else -> "12:34:56"
        }
        previewBody.text = "时间: $timeSample\n${tmpl.footerSlogan}"
        // Typeface preview on sample line
        previewBody.typeface = when (config.timeStyle) {
            TimeStyle.DIGITAL_TUBE -> android.graphics.Typeface.MONOSPACE
            TimeStyle.FLIP_CALENDAR -> android.graphics.Typeface.SERIF
            TimeStyle.RETRO_SLASH -> android.graphics.Typeface.create(
                android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.ITALIC
            )
            else -> android.graphics.Typeface.DEFAULT
        }
        val bg = GradientDrawable()
        bg.cornerRadius = 12f * resources.displayMetrics.density
        bg.setColor(tmpl.resolvedHeaderColor())
        previewCard.background = bg
        previewTitle.setTextColor(Color.WHITE)
        previewBody.setTextColor(
            when (config.timeStyle) {
                TimeStyle.DIGITAL_TUBE -> 0xFF00FF66.toInt()
                TimeStyle.RETRO_SLASH -> 0xFFD4A574.toInt()
                else -> Color.WHITE
            }
        )
    }

    companion object {
        fun newInstance(): WatermarkPickerSheet = WatermarkPickerSheet()
    }

    private class TemplateGridAdapter(
        private val items: List<WatermarkTemplate>,
        private var selected: WatermarkTemplate,
        private val onClick: (WatermarkTemplate) -> Unit
    ) : RecyclerView.Adapter<TemplateGridAdapter.H>() {

        class H(v: View) : RecyclerView.ViewHolder(v) {
            val card: View = v.findViewById(R.id.itemPickerTemplateCard)
            val name: TextView = v.findViewById(R.id.itemPickerTemplateName)
            val hint: TextView = v.findViewById(R.id.itemPickerTemplateHint)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): H {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_picker_template, parent, false)
            return H(v)
        }

        override fun onBindViewHolder(holder: H, position: Int) {
            val item = items[position]
            holder.name.text = item.cardTitle()
            holder.hint.text = item.description
            val gd = GradientDrawable()
            gd.cornerRadius = 10f * holder.itemView.resources.displayMetrics.density
            gd.setColor(item.resolvedHeaderColor())
            val strokeW = if (item == selected) 3 else 1
            val strokeC = if (item == selected) Color.WHITE else 0x66FFFFFF.toInt()
            gd.setStroke(strokeW, strokeC)
            holder.card.background = gd
            // 同步资源卡片色（drawable 备份）
            runCatching {
                val resName = TemplateFormCatalog.drawableName(item)
                val id = holder.itemView.resources.getIdentifier(
                    resName, "drawable", holder.itemView.context.packageName
                )
                if (id != 0 && item != selected) {
                    // keep gradient for stroke selection state
                }
            }
            holder.itemView.setOnClickListener {
                val old = items.indexOf(selected)
                selected = item
                if (old >= 0) notifyItemChanged(old)
                notifyItemChanged(position)
                onClick(item)
            }
        }

        override fun getItemCount(): Int = items.size
    }

    private class StyleListAdapter(
        private val items: List<TimeStyle>,
        private var selected: TimeStyle,
        private val onClick: (TimeStyle) -> Unit
    ) : RecyclerView.Adapter<StyleListAdapter.H>() {

        class H(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(R.id.itemPickerStyleName)
            val sample: TextView = v.findViewById(R.id.itemPickerStyleSample)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): H {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_picker_style, parent, false)
            return H(v)
        }

        override fun onBindViewHolder(holder: H, position: Int) {
            val item = items[position]
            holder.name.text = when (item) {
                TimeStyle.DIGITAL_TUBE -> "数码管"
                TimeStyle.FLIP_CALENDAR -> "翻页日历"
                TimeStyle.RETRO_SLASH -> "复古斜线"
                else -> "默认"
            }
            holder.sample.text = when (item) {
                TimeStyle.DIGITAL_TUBE -> "88:88:88"
                TimeStyle.FLIP_CALENDAR -> "12 34"
                TimeStyle.RETRO_SLASH -> "12/34"
                else -> "12:34:56"
            }
            holder.sample.setTextColor(
                when (item) {
                    TimeStyle.DIGITAL_TUBE -> 0xFF00FF66.toInt()
                    TimeStyle.RETRO_SLASH -> 0xFFD4A574.toInt()
                    else -> Color.WHITE
                }
            )
            holder.itemView.alpha = if (item == selected) 1f else 0.7f
            holder.itemView.setBackgroundColor(
                if (item == selected) 0x33FFFFFF.toInt() else Color.TRANSPARENT
            )
            holder.itemView.setOnClickListener {
                val old = items.indexOf(selected)
                selected = item
                if (old >= 0) notifyItemChanged(old)
                notifyItemChanged(position)
                onClick(item)
            }
        }

        override fun getItemCount(): Int = items.size
    }
}
