package com.watermark.camera.data.watermark

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.watermark.camera.data.model.TimeStyle
import com.watermark.camera.data.model.WatermarkConfig
import com.watermark.camera.data.model.WatermarkPosition
import com.watermark.camera.data.model.WatermarkTemplate
import com.watermark.camera.util.OrientationHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 单列表单卡片水印（预览 + 成片）。
 * 更小体积；表头带场景 Logo；字段精简且可自定义。
 */
class WatermarkRenderer {

    companion object {
        private const val BASE_SHORT = 1080f
        private const val MAX_CARD_W_RATIO = 0.58f
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isSubpixelText = true }
    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    data class LineSpec(
        val text: String,
        val bold: Boolean = false,
        val scale: Float = 1f,
        val colorArgb: Int? = null,
        val useTimeStyle: Boolean = false
    )

    data class CardMetrics(
        val left: Float,
        val top: Float,
        val width: Float,
        val height: Float,
        val paddingH: Float,
        val paddingV: Float,
        val fontSize: Float,
        val lineSpacing: Float,
        val radius: Float,
        val lines: List<LineSpec>
    )

    private data class FieldRow(val label: String, val value: String, val isTime: Boolean = false)

    fun draw(
        canvas: Canvas,
        areaWidth: Float,
        areaHeight: Float,
        config: WatermarkConfig,
        locationText: String,
        deviceOrientation: OrientationHelper.DeviceOrientation =
            OrientationHelper.DeviceOrientation.PORTRAIT,
        timeMs: Long = System.currentTimeMillis()
    ): CardMetrics? {
        val m = measure(areaWidth, areaHeight, config, locationText, timeMs) ?: return null
        val degrees = when (deviceOrientation) {
            OrientationHelper.DeviceOrientation.LANDSCAPE_LEFT -> 90f
            OrientationHelper.DeviceOrientation.LANDSCAPE_RIGHT -> -90f
            OrientationHelper.DeviceOrientation.UPSIDE_DOWN -> 180f
            else -> 0f
        }
        canvas.save()
        if (degrees != 0f) {
            canvas.rotate(degrees, m.left + m.width / 2f, m.top + m.height / 2f)
        }
        drawFormCard(canvas, m, config, locationText, timeMs)
        canvas.restore()
        return m
    }

    fun measure(
        areaWidth: Float,
        areaHeight: Float,
        config: WatermarkConfig,
        locationText: String,
        timeMs: Long = System.currentTimeMillis()
    ): CardMetrics? {
        if (areaWidth <= 1f || areaHeight <= 1f) return null
        val short = minOf(areaWidth, areaHeight)
        val scale = (short / BASE_SHORT).coerceIn(0.32f, 1.8f)
        val user = config.clampedFontScale().coerceIn(0.8f, 2.5f)
        val body = (12.5f * scale * user).coerceIn(11f, 36f)
        val titleSize = body * 1.22f
        val headerH = titleSize * 1.85f
        val footerH = body * 1.35f
        val rowH = body * 1.55f
        val padH = body * 0.75f
        val padV = body * 0.45f
        val radius = body * 0.55f

        val fields = buildFields(config, locationText, timeMs)
        // 单列：按最长行估算宽度
        textPaint.textSize = body
        var maxLine = titleSize * 6f
        for (f in fields) {
            textPaint.textSize = body * 0.9f
            val w = textPaint.measureText("${f.label} ${f.value}")
            if (w > maxLine) maxLine = w
        }
        val cardW = (padH * 2f + maxLine + body * 1.8f).coerceIn(
            body * 12f,
            areaWidth * MAX_CARD_W_RATIO
        )
        val bodyH = padV + fields.size * rowH + padV
        val cardH = headerH + bodyH + footerH
        val (left, top) = resolveOrigin(config, areaWidth, areaHeight, cardW, cardH)
        return CardMetrics(left, top, cardW, cardH, padH, padV, body, body * 0.25f, radius, emptyList())
    }

    private fun drawFormCard(
        canvas: Canvas,
        m: CardMetrics,
        config: WatermarkConfig,
        locationText: String,
        timeMs: Long
    ) {
        val tmpl = config.template
        val formSpec = TemplateFormCatalog.specOf(tmpl)
        val headerColor = withAlpha(tmpl.resolvedHeaderColor(), config.transparency)
        val bodyColor = withAlpha(0xFFFFFFFF.toInt(), (config.transparency * 0.95f).coerceIn(0.55f, 1f))
        val labelColor = tmpl.resolvedHeaderColor()
        val valueColor = 0xFF222222.toInt()
        val titleColor = 0xFFFFFFFF.toInt()
        val footerTextColor = 0xCCFFFFFF.toInt()

        val rect = RectF(m.left, m.top, m.left + m.width, m.top + m.height)
        val radius = m.radius
        val titleSize = m.fontSize * 1.22f
        val headerH = titleSize * 1.85f
        val footerH = m.fontSize * 1.35f
        val bodyTop = m.top + headerH
        val bodyBottom = m.top + m.height - footerH

        canvas.save()
        val clip = Path().apply { addRoundRect(rect, radius, radius, Path.Direction.CW) }
        canvas.clipPath(clip)

        fillPaint.style = Paint.Style.FILL
        fillPaint.color = bodyColor
        canvas.drawRect(rect, fillPaint)

        fillPaint.color = headerColor
        canvas.drawRect(m.left, m.top, m.left + m.width, bodyTop, fillPaint)

        fillPaint.color = headerColor
        canvas.drawRect(m.left, bodyBottom, m.left + m.width, m.top + m.height, fillPaint)
        canvas.restore()

        fillPaint.style = Paint.Style.STROKE
        fillPaint.strokeWidth = maxOf(1.2f, m.fontSize * 0.05f)
        fillPaint.color = withAlpha(tmpl.resolvedHeaderColor(), 0.9f)
        canvas.drawRoundRect(rect, radius, radius, fillPaint)
        fillPaint.style = Paint.Style.FILL

        // Logo
        val iconCx = m.left + m.paddingH + m.fontSize * 0.55f
        val iconCy = m.top + headerH * 0.5f
        val iconR = m.fontSize * 0.62f
        drawTemplateLogo(canvas, tmpl, iconCx, iconCy, iconR)

        // Title
        val title = if (tmpl == WatermarkTemplate.GENERAL && config.customTitle.isNotBlank()) {
            config.customTitle.trim()
        } else {
            formSpec.title
        }
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = titleSize
        textPaint.color = titleColor
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText(title, iconCx + iconR + m.fontSize * 0.45f, m.top + headerH * 0.62f + titleSize * 0.12f, textPaint)

        // Single-column fields
        val fields = buildFields(config, locationText, timeMs)
        val labelSize = m.fontSize * 0.88f
        val valueSize = m.fontSize * 0.92f
        val rowH = m.fontSize * 1.55f
        var rowY = bodyTop + m.paddingV + labelSize
        textPaint.textAlign = Paint.Align.LEFT
        for (row in fields) {
            // accent bar
            accentPaint.color = labelColor
            canvas.drawRoundRect(
                RectF(
                    m.left + m.paddingH * 0.55f,
                    rowY - labelSize * 0.72f,
                    m.left + m.paddingH * 0.55f + labelSize * 0.16f,
                    rowY + labelSize * 0.12f
                ),
                2f, 2f, accentPaint
            )
            val textX = m.left + m.paddingH
            textPaint.typeface = Typeface.DEFAULT
            textPaint.textSize = labelSize
            textPaint.color = labelColor
            canvas.drawText(row.label, textX, rowY, textPaint)
            val lw = textPaint.measureText(row.label)
            textPaint.typeface = if (row.isTime) typefaceFor(config.timeStyle, false) else Typeface.DEFAULT
            textPaint.textSize = valueSize
            textPaint.color = valueColor
            val display = row.value.ifBlank { "—" }
            canvas.drawText(display, textX + lw, rowY, textPaint)
            rowY += rowH
        }

        // Footer
        textPaint.typeface = Typeface.DEFAULT
        textPaint.textSize = m.fontSize * 0.72f
        textPaint.color = footerTextColor
        textPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(formSpec.slogan, m.left + m.width / 2f, bodyBottom + footerH * 0.62f, textPaint)
    }

    private fun drawTemplateLogo(
        canvas: Canvas,
        template: WatermarkTemplate,
        cx: Float,
        cy: Float,
        r: Float
    ) {
        iconPaint.style = Paint.Style.FILL
        iconPaint.color = 0x33FFFFFF
        canvas.drawCircle(cx, cy, r, iconPaint)
        iconPaint.color = 0xFFFFFFFF.toInt()
        iconPaint.style = Paint.Style.STROKE
        iconPaint.strokeWidth = maxOf(1.5f, r * 0.12f)
        iconPaint.strokeCap = Paint.Cap.ROUND
        iconPaint.strokeJoin = Paint.Join.ROUND
        val path = Path()
        when (template) {
            WatermarkTemplate.PROPERTY_INSPECTION -> {
                // shield
                path.moveTo(cx, cy - r * 0.7f)
                path.lineTo(cx + r * 0.55f, cy - r * 0.35f)
                path.lineTo(cx + r * 0.45f, cy + r * 0.25f)
                path.quadTo(cx, cy + r * 0.75f, cx - r * 0.45f, cy + r * 0.25f)
                path.lineTo(cx - r * 0.55f, cy - r * 0.35f)
                path.close()
                iconPaint.style = Paint.Style.FILL
                canvas.drawPath(path, iconPaint)
            }
            WatermarkTemplate.DUTY -> {
                // person / badge
                canvas.drawCircle(cx, cy - r * 0.28f, r * 0.28f, iconPaint.apply { style = Paint.Style.FILL })
                path.addOval(RectF(cx - r * 0.45f, cy + r * 0.05f, cx + r * 0.45f, cy + r * 0.7f), Path.Direction.CW)
                canvas.drawPath(path, iconPaint)
            }
            WatermarkTemplate.ENGINEERING -> {
                // hard hat
                iconPaint.style = Paint.Style.FILL
                canvas.drawArc(RectF(cx - r * 0.55f, cy - r * 0.55f, cx + r * 0.55f, cy + r * 0.25f), 180f, 180f, true, iconPaint)
                canvas.drawRect(cx - r * 0.65f, cy + r * 0.05f, cx + r * 0.65f, cy + r * 0.28f, iconPaint)
            }
            WatermarkTemplate.ATTENDANCE -> {
                // calendar
                iconPaint.style = Paint.Style.STROKE
                canvas.drawRoundRect(RectF(cx - r * 0.5f, cy - r * 0.4f, cx + r * 0.5f, cy + r * 0.5f), r * 0.1f, r * 0.1f, iconPaint)
                canvas.drawLine(cx - r * 0.5f, cy - r * 0.1f, cx + r * 0.5f, cy - r * 0.1f, iconPaint)
                iconPaint.style = Paint.Style.FILL
                canvas.drawCircle(cx - r * 0.18f, cy + r * 0.18f, r * 0.08f, iconPaint)
                canvas.drawCircle(cx + r * 0.18f, cy + r * 0.18f, r * 0.08f, iconPaint)
            }
            WatermarkTemplate.EVIDENCE -> {
                // camera
                iconPaint.style = Paint.Style.STROKE
                canvas.drawRoundRect(RectF(cx - r * 0.55f, cy - r * 0.35f, cx + r * 0.55f, cy + r * 0.4f), r * 0.12f, r * 0.12f, iconPaint)
                canvas.drawCircle(cx, cy + r * 0.02f, r * 0.22f, iconPaint)
                iconPaint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy + r * 0.02f, r * 0.1f, iconPaint)
            }
            else -> {
                // grid 2x2
                iconPaint.style = Paint.Style.FILL
                val s = r * 0.28f
                val g = r * 0.12f
                canvas.drawRoundRect(RectF(cx - s - g, cy - s - g, cx - g, cy - g), s * 0.2f, s * 0.2f, iconPaint)
                canvas.drawRoundRect(RectF(cx + g, cy - s - g, cx + s + g, cy - g), s * 0.2f, s * 0.2f, iconPaint)
                canvas.drawRoundRect(RectF(cx - s - g, cy + g, cx - g, cy + s + g), s * 0.2f, s * 0.2f, iconPaint)
                canvas.drawRoundRect(RectF(cx + g, cy + g, cx + s + g, cy + s + g), s * 0.2f, s * 0.2f, iconPaint)
            }
        }
    }

    private fun buildFields(
        config: WatermarkConfig,
        locationText: String,
        timeMs: Long
    ): List<FieldRow> {
        val tmpl = config.template
        val timeStr = formatTime(config.timeStyle, timeMs)
        val loc = locationText.ifBlank { "定位中…" }
        val rows = mutableListOf<FieldRow>()
        rows.add(FieldRow("时间: ", timeStr, isTime = true))
        if (config.showLocation) {
            rows.add(FieldRow("地点: ", loc))
        }
        val spec = TemplateFormCatalog.specOf(tmpl)
        for (f in spec.editable) {
            val v = TemplateFormCatalog.readField(config, tmpl, f.key)
            rows.add(FieldRow("${f.label}: ", v.ifBlank { "—" }))
        }
        return rows
    }

    private fun formatTime(style: TimeStyle, timeMs: Long): String {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date(timeMs))
        val time = when (style) {
            TimeStyle.DIGITAL_TUBE, TimeStyle.DEFAULT ->
                SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(Date(timeMs))
            TimeStyle.FLIP_CALENDAR ->
                SimpleDateFormat("HH:mm", Locale.CHINA).format(Date(timeMs))
            TimeStyle.RETRO_SLASH ->
                SimpleDateFormat("HH/mm/ss", Locale.CHINA).format(Date(timeMs))
        }
        return "$date $time"
    }

    private fun typefaceFor(style: TimeStyle, bold: Boolean): Typeface {
        val base = when (style) {
            TimeStyle.DIGITAL_TUBE -> Typeface.MONOSPACE
            TimeStyle.FLIP_CALENDAR -> Typeface.SERIF
            TimeStyle.RETRO_SLASH -> Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
            else -> Typeface.DEFAULT
        }
        return if (bold) Typeface.create(base, Typeface.BOLD) else base
    }

    private fun withAlpha(color: Int, alpha01: Float): Int {
        val a = (alpha01.coerceIn(0.25f, 1f) * 255).toInt().coerceIn(50, 255)
        return (a shl 24) or (color and 0x00FFFFFF)
    }

    private fun resolveOrigin(
        config: WatermarkConfig,
        areaWidth: Float,
        areaHeight: Float,
        cardWidth: Float,
        cardHeight: Float
    ): Pair<Float, Float> {
        val maxL = (areaWidth - cardWidth).coerceAtLeast(0f)
        val maxT = (areaHeight - cardHeight).coerceAtLeast(0f)
        val cx = config.customX
        val cy = config.customY
        if (cx != null && cy != null) {
            return (cx.coerceIn(0f, 1f) * maxL).coerceIn(0f, maxL) to
                (cy.coerceIn(0f, 1f) * maxT).coerceIn(0f, maxT)
        }
        return when (config.position) {
            WatermarkPosition.TOP_LEFT -> 0f to 0f
            WatermarkPosition.TOP_RIGHT -> maxL to 0f
            WatermarkPosition.BOTTOM_LEFT -> 0f to maxT
            WatermarkPosition.BOTTOM_RIGHT -> maxL to maxT
            WatermarkPosition.CENTER -> (maxL / 2f) to (maxT / 2f)
        }
    }
}
