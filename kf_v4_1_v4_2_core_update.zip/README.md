KF V4.1-V4.2 Core Update Package

用途：
更新现有V4项目核心功能。

保护：
不包含：
.github/workflows
README
Gradle配置
Manifest
签名文件

应用方式：
由 apply-kf-update.yml 自动读取 kf_manifest.txt。
