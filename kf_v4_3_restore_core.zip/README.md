# KF Restore: undo stub package + compile fixes

## What went wrong with kf_v4_1_v4_2_core_update.zip
That package replaced REAL implementations with empty stubs:

- CameraRepositoryImpl (no longer implements CameraRepository)
- StorageRepositoryImpl (no longer implements StorageRepository)
- CollageEngine / ImageProcessingPipeline / WatermarkConfigDataSource stubs

Hilt @Binds then fails:
  "parameters types must be assignable to return types"

## This package restores
Full CameraRepositoryImpl, StorageRepositoryImpl, CollageEngine,
ImageProcessingPipeline, WatermarkConfigDataSource from working source,
plus BitmapDecoder/App clash fix, CapturePhotoUseCase (300ms cooldown),
ProcessPhotoUseCase + CameraViewModel photo-save pipeline.

## How to apply
1. Upload this zip as: kf_v4_3_restore_core.zip (must start with kf)
2. Run: Apply KF Update Package
3. Run: Build Stable APK
