KF package: fix BitmapDecoder setAppContext JVM clash
1. Upload this zip to repo root as kf_v4_bitmapdecoder_fix.zip
2. Run workflow: Apply KF Update Package (or apply-kf-fix.yml)
3. Then run Build Stable APK
